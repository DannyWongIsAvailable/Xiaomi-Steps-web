import axios from 'axios'

const FORM_HEADERS = {
  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  app_name: 'com.xiaomi.hm.health',
}

const LOGIN_API = 'https://api-user.huami.com'
const ACCOUNT_API = 'https://account.huami.com'
const ACCOUNT_CN_API = 'https://account-cn.huami.com'
const DATA_API = 'https://api-mifit-cn.huami.com'

function normalizeAccount(account) {
  const value = String(account ?? '').trim()

  if (/^1\d{10}$/.test(value)) {
    return {
      account: `+86${value}`,
      thirdName: 'huami_phone',
    }
  }

  return {
    account: value,
    thirdName: 'huami',
  }
}

function localDateString(date = new Date()) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function getTimestamp() {
  // 浏览器无法像原 Python 脚本一样通过 UDP 访问 NTP，使用当前 Unix 时间戳。
  return Math.floor(Date.now() / 1000)
}

function throwHttpError(error, fallbackMessage) {
  if (axios.isAxiosError(error)) {
    if (!error.response) {
      const networkError = new Error(
        '浏览器无法访问 Huami API。可能被 CORS 跨域策略拦截，或当前网络无法连接接口。',
      )
      networkError.code = 'NETWORK_OR_CORS'
      throw networkError
    }

    const status = error.response.status
    const apiMessage =
      error.response.data?.message ||
      error.response.data?.error ||
      error.response.statusText

    const httpError = new Error(
      apiMessage ? `${fallbackMessage}（${status}：${apiMessage}）` : `${fallbackMessage}（HTTP ${status}）`,
    )
    httpError.status = status
    throw httpError
  }

  throw error
}

export async function login(account, password) {
  const normalized = normalizeAccount(account)

  const firstBody = new URLSearchParams({
    client_id: 'HuaMi',
    country_code: 'CN',
    json_response: 'true',
    name: normalized.account,
    password,
    redirect_uri: 'https://s3-us-west-2.amazonaws.com/hm-registration/successsignin.html',
    state: 'REDIRECTION',
    token: 'access',
  })

  let accessCode

  try {
    const response = await axios.post(
      `${LOGIN_API}/registrations/${encodeURIComponent(normalized.account)}/tokens`,
      firstBody.toString(),
      {
        headers: FORM_HEADERS,
        timeout: 15000,
      },
    )

    accessCode = response.data?.access

    if (!accessCode) {
      const error = new Error('Zepp Life 账号或密码不正确，未获取到 access token。')
      error.code = 'LOGIN_FAILED'
      throw error
    }
  } catch (error) {
    if (error?.code === 'LOGIN_FAILED') throw error

    if (axios.isAxiosError(error) && error.response?.status === 429) {
      const rateError = new Error('请求过于频繁，请稍后再试。')
      rateError.status = 429
      throw rateError
    }

    throwHttpError(error, 'Zepp Life 登录失败')
  }

  const secondBody = new URLSearchParams({
    app_name: 'com.xiaomi.hm.health',
    country_code: 'CN',
    code: accessCode,
    device_id: '00:00:00:00:00:00',
    device_model: 'android_phone',
    app_version: '6.12.0',
    grant_type: 'access_token',
    allow_registration: 'false',
    source: 'com.xiaomi.hm.health',
    third_name: normalized.thirdName,
  })

  try {
    const response = await axios.post(`${ACCOUNT_API}/v2/client/login`, secondBody.toString(), {
      headers: FORM_HEADERS,
      timeout: 15000,
    })

    const tokenInfo = response.data?.token_info
    const loginToken = tokenInfo?.login_token
    const userId = tokenInfo?.user_id

    if (!loginToken || !userId) {
      const error = new Error('登录成功，但未获取到 login_token 或 user_id。')
      error.code = 'TOKEN_FAILED'
      throw error
    }

    return { loginToken, userId }
  } catch (error) {
    if (error?.code === 'TOKEN_FAILED') throw error
    throwHttpError(error, '获取登录 Token 失败')
  }
}

export async function getAppToken(loginToken) {
  try {
    const response = await axios.get(`${ACCOUNT_CN_API}/v1/client/app_tokens`, {
      params: { login_token: loginToken },
      headers: FORM_HEADERS,
      timeout: 15000,
    })

    const appToken = response.data?.token_info?.app_token

    if (!appToken) {
      const error = new Error('未获取到 app_token。')
      error.code = 'APP_TOKEN_FAILED'
      throw error
    }

    return appToken
  } catch (error) {
    if (error?.code === 'APP_TOKEN_FAILED') throw error
    throwHttpError(error, '获取 app_token 失败')
  }
}

function buildDataJson(steps, dateToday, deviceId) {
  return (
    '%5b%7b%22data_hr%22%3a%22' +
    '%5c%2fv7%2b'.repeat(480) +
    `%22%2c%22date%22%3a%22${dateToday}%22%2c%22data%22%3a%5b%7b%22start%22%3a0%2c%22stop%22%3a1439%2c%22value%22%3a%22` +
    'A'.repeat(5760) +
    `%22%2c%22tz%22%3a32%2c%22did%22%3a%22${deviceId}%22%2c%22src%22%3a24%7d%5d%2c%22summary%22%3a%22%7b%5c%22v%5c%22%3a6%2c%5c%22slp%5c%22%3a%7b%5c%22st%5c%22%3a0%2c%5c%22ed%5c%22%3a0%2c%5c%22dp%5c%22%3a0%2c%5c%22lt%5c%22%3a0%2c%5c%22wk%5c%22%3a0%2c%5c%22usrSt%5c%22%3a-1440%2c%5c%22usrEd%5c%22%3a-1440%2c%5c%22wc%5c%22%3a0%2c%5c%22is%5c%22%3a0%2c%5c%22lb%5c%22%3a0%2c%5c%22to%5c%22%3a0%2c%5c%22dt%5c%22%3a0%2c%5c%22rhr%5c%22%3a0%2c%5c%22ss%5c%22%3a0%7d%2c%5c%22stp%5c%22%3a%7b%5c%22ttl%5c%22%3a${steps}%2c%5c%22dis%5c%22%3a0%2c%5c%22cal%5c%22%3a0%2c%5c%22wk%5c%22%3a0%2c%5c%22rn%5c%22%3a0%2c%5c%22runDist%5c%22%3a0%2c%5c%22runCal%5c%22%3a0%2c%5c%22stage%5c%22%3a%5b%5d%7d%2c%5c%22goal%5c%22%3a0%2c%5c%22tz%5c%22%3a%5c%2228800%5c%22%7d%22%2c%22source%22%3a24%2c%22type%22%3a0%7d%5d`
  )
}

export async function changeSteps(userId, appToken, steps) {
  const timestamp = getTimestamp()
  const dateToday = localDateString()
  const deviceId = '0000000000000000'
  const dataJson = buildDataJson(steps, dateToday, deviceId)

  const body =
    `userid=${encodeURIComponent(userId)}` +
    `&last_sync_data_time=${timestamp}` +
    '&device_type=0' +
    `&last_deviceid=${deviceId}` +
    `&data_json=${dataJson}`

  try {
    const response = await axios.post(`${DATA_API}/v1/data/band_data.json?&t=${timestamp}`, body, {
      headers: {
        ...FORM_HEADERS,
        apptoken: appToken,
      },
      timeout: 20000,
    })

    if (response.data?.message !== 'success') {
      const message = response.data?.message || 'Huami API 未返回 success。'
      const error = new Error(`步数修改失败：${message}`)
      error.code = 'CHANGE_STEPS_FAILED'
      throw error
    }

    return {
      success: true,
      steps,
      userId,
      date: dateToday,
      response: response.data,
    }
  } catch (error) {
    if (error?.code === 'CHANGE_STEPS_FAILED') throw error
    throwHttpError(error, '提交步数失败')
  }
}

export async function modifySteps(account, password, steps, onProgress) {
  const parsedSteps = Number.parseInt(steps, 10)

  if (!account?.trim()) throw new Error('请输入 Zepp Life 账号。')
  if (!password) throw new Error('请输入 Zepp Life 密码。')
  if (!Number.isInteger(parsedSteps) || parsedSteps <= 0) {
    throw new Error('请输入有效的目标步数。')
  }

  onProgress?.('login', '正在登录 Zepp Life…')
  const { loginToken, userId } = await login(account, password)

  onProgress?.('token', '登录成功，正在获取 app_token…')
  const appToken = await getAppToken(loginToken)

  onProgress?.('submit', 'Token 获取成功，正在提交步数…')
  return changeSteps(userId, appToken, parsedSteps)
}
