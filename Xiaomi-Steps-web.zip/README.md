# Xiaomi Steps Web

基于 Vue 3 + Vite 的 Zepp Life 步数修改页面。

## 特点

- 纯前端页面，不包含自建后端。
- 使用 Axios 由浏览器直接请求 Huami / Zepp Life API。
- 支持 Zepp Life 邮箱账号和中国大陆手机号账号。
- 目标步数可手动输入，也可随机生成 25,000–50,000 步。
- 账号、密码不会由页面主动写入 `localStorage` 或其他持久化存储。

> 请使用可以通过“账号 + 密码”登录的 Zepp Life 账号。第三方一键登录方式不适用于此调用流程。

## 安装

```bash
pnpm install
```

Axios 已作为项目依赖：

```bash
pnpm install axios
```

## 开发

```bash
pnpm dev
```

默认访问 Vite 输出的本地地址，例如：

```text
http://localhost:5173/
```

## 构建

```bash
pnpm build
```

构建结果位于：

```text
dist/
```

可将 `dist` 部署到 Cloudflare Pages 等静态托管平台。

## 项目结构

```text
.
├─ index.html
├─ package.json
├─ pnpm-lock.yaml
├─ vite.config.js
├─ public/
└─ src/
   ├─ App.vue
   ├─ main.js
   ├─ style.css
   └─ api/
      └─ huami.js
```

## 浏览器跨域说明

本项目按“纯前端直接访问 Huami API”的方式实现，因此实际请求是否成功取决于 Huami API 的 CORS 策略。

如果浏览器控制台出现 CORS、preflight 或 `Network Error`，表示目标接口没有允许当前页面来源直接跨域访问。这属于浏览器安全策略，静态页面本身无法绕过。

另外，原 Python 版本通过 UDP/NTP 获取时间；浏览器不能建立这种 UDP Socket，因此 Web 版本使用浏览器当前的 Unix 时间戳。

## 免责声明

本项目仅用于学习与技术研究。请遵守 Zepp Life / Huami 平台相关服务协议，并自行承担使用产生的后果。
